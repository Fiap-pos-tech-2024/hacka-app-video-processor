<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

Este é um projeto base TypeScript. Use sempre ES Modules e mantenha a estrutura src/ para código-fonte e dist/ para arquivos compilados.
